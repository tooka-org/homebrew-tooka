# Stylesheet

## Text
Font: Nunito
Style: Bold

## Colors
- background grey: #2f434b
- light orange: #f99a31
- dark orange (red): #dc5135
- main blue: #23789a

## ASCII Art

```sh
  _____           _         
 |_   _|__   ___ | | ____ _ 
   | |/ _ \ / _ \| |/ / _' |
   | | (_) | (_) |   < (_| |
   |_|\___/ \___/|_|\_\__,_|
```